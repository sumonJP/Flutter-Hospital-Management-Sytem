package com.example.demo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RecordDa {
	
	//====================================get all records from payment===================
			public List<Payment> getadmittedpatient(Date dateFrom,Date dateTo) {

		List<Payment> slist = new ArrayList<>();

		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hms", "root", "sumon123");
			PreparedStatement ps = con.prepareStatement("select * from payment where date between ? and ?");
			ps.setDate(1, dateFrom);
			ps.setDate(2, dateTo);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				slist.add(new Payment(rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getDouble(7),rs.getDouble(8),rs.getDouble(9),rs.getDouble(10),rs.getDouble(11),rs.getDouble(12),rs.getDouble(13),rs.getDouble(14),rs.getDouble(15),rs.getDate(16),rs.getDouble(17)));
			}
	

		} catch (Exception ex) {
			// TODO: handle exception
		}

		return slist;
	}

}
